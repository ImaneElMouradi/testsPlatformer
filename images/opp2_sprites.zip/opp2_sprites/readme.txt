Thanks for downloading the OPP assets!
Since 2013 over 35 pixel artist have worked on these sprites and tiles, hoping that they'd be useful to you! Enjoy :D
YOU ARE FREE TO DO WHATEVER YOU WANT WITH THESE ASSETS! THEY ARE IN THE PUBLIC DOMAIN

You can always find all of the latest updates of the assets on our website:
http://www.openpixelproject.com/

We'd love to hear about what you might use this for, leave us a message on our forums or on the chat:

http://pixeljoint.com/forum/forum_topics.asp?FID=23
https://discord.gg/kEP2UDZ

New contributions, improvements and expansions are always welcome. We have a style guide, and love to help out anyone who wants to learn more about pixel art. Come say hello!


